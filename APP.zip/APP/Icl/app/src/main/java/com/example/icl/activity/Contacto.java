package com.example.icl.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.icl.R;

public class Contacto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);
    }
}